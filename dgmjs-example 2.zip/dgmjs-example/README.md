# DGM.js minimal example

- Vite
- React
- TypeScript
- Tailwind CSS
- Lucide Icons
